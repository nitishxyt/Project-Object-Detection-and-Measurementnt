from ultralytics import YOLO
import cv2

# Initialize YOLOv5 model
model = YOLO("yolov8n.pt")

# Predict and display detections
model.predict(source="2", show=True, conf=0.5)