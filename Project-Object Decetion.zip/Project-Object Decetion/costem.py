import sys
from ultralytics import YOLO
import cv2

# Load model
model = YOLO("yolov8n.pt")  # or your custom-trained model

# Get class from CLI argument
target_class = sys.argv[1] if len(sys.argv) > 1 else None

class_names = model.names
allowed_ids = []

if target_class:
    allowed_ids = [i for i, name in class_names.items() if name == target_class]
    print(f"Detecting only: {target_class}")
else:
    allowed_ids = list(class_names.keys())
    print("Detecting all objects")

cap = cv2.VideoCapture(2)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    results = model(frame)[0]

    for box in results.boxes:
        cls_id = int(box.cls[0])
        if cls_id in allowed_ids:
            conf = box.conf[0]
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            label = class_names[cls_id]
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0,255,0), 2)
            cv2.putText(frame, f'{label} {conf:.2f}', (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)

    cv2.imshow("Custom Detection", frame)
    if cv2.waitKey(1) == 27:
        break

cap.release()
cv2.destroyAllWindows()
