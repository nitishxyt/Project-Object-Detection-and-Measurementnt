import tkinter as tk
from tkinter import messagebox
import subprocess
import sys

# --- Page switching functions ---
def show_main_page():
    login_frame.pack_forget()
    main_frame.pack()

def show_login_page():
    main_frame.pack_forget()
    login_frame.pack()

def show_measurement_page():
    main_frame.pack_forget()
    measurement_frame.pack()

def back_to_main_from_measurement():
    measurement_frame.pack_forget()
    main_frame.pack()

def show_objectdetection_page():
    main_frame.pack_forget()
    objectdetection_frame.pack()

def back_to_main_from_objectdetection():
    objectdetection_frame.pack_forget()
    main_frame.pack()

def show_custom_frame():
    objectdetection_frame.pack_forget()
    custom_frame.pack()

def back_from_custom_frame():
    custom_frame.pack_forget()
    objectdetection_frame.pack()

# --- Login check ---
def check_login():
    username = entry_username.get()
    password = entry_password.get()
    if username == "abesit" and password == "1234":
        show_main_page()
    else:
        messagebox.showerror("Login Failed", "Invalid credentials")

# --- Script launching functions ---
def run_object_detection():
    subprocess.Popen([sys.executable, "livedect.py"],
                     creationflags=subprocess.CREATE_NEW_CONSOLE)

def run_object_custom():
    subprocess.Popen([sys.executable, "costem.py"],
                     creationflags=subprocess.CREATE_NEW_CONSOLE)

def run_set_camera():
    subprocess.Popen([sys.executable, "SetPexl.py"],
                     creationflags=subprocess.CREATE_NEW_CONSOLE)

def run_manual_distance():
    subprocess.Popen([sys.executable, "manual.py"],
                     creationflags=subprocess.CREATE_NEW_CONSOLE)

def run_live_calculation():
    subprocess.Popen([sys.executable, "utility.py"],
                     creationflags=subprocess.CREATE_NEW_CONSOLE)

def run_live_with_class(cls_name):
    subprocess.Popen([sys.executable, "costem.py", cls_name],
                     creationflags=subprocess.CREATE_NEW_CONSOLE)

# --- Main Window ---
root = tk.Tk()
root.title("AI Object Detection App")
root.geometry("600x600")

BUTTON_FONT = ("Arial", 14)
LABEL_FONT = ("Arial", 16)

# --- Login Page ---
login_frame = tk.Frame(root)

tk.Label(login_frame, text="Username", font=LABEL_FONT).pack(pady=5)
entry_username = tk.Entry(login_frame, font=BUTTON_FONT)
entry_username.pack()

tk.Label(login_frame, text="Password", font=LABEL_FONT).pack(pady=5)
entry_password = tk.Entry(login_frame, show="*", font=BUTTON_FONT)
entry_password.pack()

tk.Button(login_frame, text="Submit", command=check_login, font=BUTTON_FONT).pack(pady=10)
login_frame.pack()

# --- Main Page ---
main_frame = tk.Frame(root)

tk.Label(main_frame, text="Choose an Option", font=LABEL_FONT).pack(pady=10)
tk.Button(main_frame, text="Object Detection", font=BUTTON_FONT, command=show_objectdetection_page).pack(pady=5)
tk.Button(main_frame, text="Object Measurement", font=BUTTON_FONT, command=show_measurement_page).pack(pady=5)
tk.Button(main_frame, text="Back", font=BUTTON_FONT, command=show_login_page).pack(pady=10)

# --- Measurement Page ---
measurement_frame = tk.Frame(root)

tk.Label(measurement_frame, text="Measurement Options", font=LABEL_FONT).pack(pady=10)
tk.Button(measurement_frame, text="Set Your Camera Position", font=BUTTON_FONT, command=run_set_camera).pack(pady=5)
tk.Button(measurement_frame, text="Calculate Distance Manually", font=BUTTON_FONT, command=run_manual_distance).pack(pady=5)
tk.Button(measurement_frame, text="Live Measurement", font=BUTTON_FONT, command=run_live_calculation).pack(pady=5)
tk.Button(measurement_frame, text="Back", font=BUTTON_FONT, command=back_to_main_from_measurement).pack(pady=10)

# --- Object Detection Page ---
objectdetection_frame = tk.Frame(root)

tk.Label(objectdetection_frame, text="Object Detection Options", font=LABEL_FONT).pack(pady=10)
tk.Button(objectdetection_frame, text="Random Detection", font=BUTTON_FONT, command=run_object_detection).pack(pady=5)
tk.Button(objectdetection_frame, text="Custom Detection (all classes)", font=BUTTON_FONT, command=run_object_custom).pack(pady=5)
tk.Button(objectdetection_frame, text="Custom Detection Options", font=BUTTON_FONT, command=show_custom_frame).pack(pady=5)
tk.Button(objectdetection_frame, text="Back", font=BUTTON_FONT, command=back_to_main_from_objectdetection).pack(pady=10)

# --- Custom Detection Page ---
custom_frame = tk.Frame(root)

tk.Label(custom_frame, text="Custom Class Detection", font=LABEL_FONT).pack(pady=10)
tk.Button(custom_frame, text="Detect Person", font=BUTTON_FONT, command=lambda: run_live_with_class("person")).pack(pady=5)
tk.Button(custom_frame, text="Detect Cat", font=BUTTON_FONT, command=lambda: run_live_with_class("cat")).pack(pady=5)
tk.Button(custom_frame, text="Detect Dog", font=BUTTON_FONT, command=lambda: run_live_with_class("dog")).pack(pady=5)
tk.Button(custom_frame, text="Back", font=BUTTON_FONT, command=back_from_custom_frame).pack(pady=10)

# --- Run the app ---
root.mainloop()
