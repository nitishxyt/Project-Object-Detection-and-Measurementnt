import cv2
import math

points = []

def draw_circle(event, x, y, flags, param):
    global points
    if event == cv2.EVENT_LBUTTONDOWN: 
        if len(points) == 2:
            points = []
        points.append((x, y))

cv2.namedWindow("frame")
cv2.setMouseCallback("frame", draw_circle)

cap = cv2.VideoCapture(2)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    for pt in points:
        cv2.circle(frame, pt, 5, (0, 0, 255), -1)

    if len(points) == 2:
        pt1, pt2 = points
        distance_pix = math.hypot(pt2[0] - pt1[0], pt2[1] - pt1[1])

        cv2.putText(frame, f"{int(distance_pix)} px", (pt1[0], pt1[1] - 10), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, (36, 255, 12), 2)

    cv2.imshow('frame', frame)
    
    key = cv2.waitKey(1)
    if key == 27:  # Escape key to exit
        break

cap.release()
cv2.destroyAllWindows()
