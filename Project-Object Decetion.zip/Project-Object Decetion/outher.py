import tkinter as tk
from tkinter import messagebox
import subprocess
import subprocess
import sys
import os


# --- Page switching functions ---
def show_main_page():
    login_frame.pack_forget()
    main_frame.pack()

def show_login_page():
    main_frame.pack_forget()
    login_frame.pack()

def show_measurement_page():
    main_frame.pack_forget()
    measurement_frame.pack()

def back_to_main_from_measurement():
    measurement_frame.pack_forget()
    main_frame.pack()

# --- Login check ---
def check_login():
    username = entry_username.get()
    password = entry_password.get()
    if username == "nitish" and password == "1234":
        show_main_page()
    else:
        messagebox.showerror("Login Failed", "Invalid credentials")

# --- Script launching functions ---


def run_object_detection():
    subprocess.Popen([sys.executable, "livedect.py"],
                     creationflags=subprocess.CREATE_NEW_CONSOLE)

def run_set_camera():
    subprocess.Popen([sys.executable, "SetPexl.py"],
                     creationflags=subprocess.CREATE_NEW_CONSOLE)
def show_objectdetection_page():
    main_frame.pack_forget()
    objectdetection_frame.pack()

def run_manual_distance():
    subprocess.Popen([sys.executable, "manual.py"],
                     creationflags=subprocess.CREATE_NEW_CONSOLE)

def run_live_calculation():
    subprocess.Popen([sys.executable, "utility.py"],
                     creationflags=subprocess.CREATE_NEW_CONSOLE)
def run_object_custom():
    subprocess.Popen([sys.executable, "costem.py"],
                     creationflags=subprocess.CREATE_NEW_CONSOLE)
# --- Main Window ---
root = tk.Tk()
root.title("Loging-Page ")
root.geometry("600x600")

# --- Login Page ---
login_frame = tk.Frame(root)

tk.Label(login_frame, text="Username",font=("Arial", 20 )).pack(pady=5)
entry_username = tk.Entry(login_frame)
entry_username.pack()

tk.Label(login_frame, text="Password",font=("Arial", 20 )).pack(pady=5)
entry_password = tk.Entry(login_frame, show="*")
entry_password.pack()

tk.Button(login_frame, text="Submit", command=check_login,font=("Arial", 10 )).pack(pady=10)
login_frame.pack()

# --- Main Page ---
main_frame = tk.Frame(root)

tk.Label(main_frame, text="Choose an Option",font=("Arial", 12)).pack(pady=10)
tk.Button(main_frame, text="Object Detection", font=("Arial", 12),command=show_objectdetection_page).pack(pady=5)
tk.Button(main_frame, text="Object Measurement",font=("Arial", 12), command=show_measurement_page).pack(pady=5)
tk.Button(main_frame, text="Back", command=show_login_page).pack(pady=10)

# --- Measurement Sub-Options Page ---
measurement_frame = tk.Frame(root)

tk.Label(measurement_frame, text="Measurement Options").pack(pady=10)
tk.Button(measurement_frame, text="Set Your Camera Position", font=("Arial", 12 ),command=run_set_camera).pack(pady=5)
tk.Button(measurement_frame, text="Calculate Distance Manually", font=("Arial", 12),command=run_manual_distance).pack(pady=5)
tk.Button(measurement_frame, text="Live Measurement", font=("Arial", 12),command=run_live_calculation).pack(pady=5)
tk.Button(measurement_frame, text="Back", command=back_to_main_from_measurement).pack(pady=10)


objectdetection_frame =tk.Frame(root)

tk.Label(objectdetection_frame, text="ObjectDetection Options",font=("Arial", 12 )).pack(pady=10)
tk.Button(objectdetection_frame, text="Random Detection", font=("Arial", 12 ),command=run_object_detection).pack(pady=5)
tk.Button(objectdetection_frame, text="Custom Detection", font=("Arial", 12 ),command=run_object_custom).pack(pady=5)
tk.Button(objectdetection_frame, text="Back", command=back_to_main_from_measurement).pack(pady=10)
# --- Run the app ---
root.mainloop()

