import cv2
import torch
import numpy as np
from ultralytics import YOLO

# Load YOLOv8 model
model = YOLO("yolov8n.pt")

# Camera calibration (adjust based on actual measurement)
PIXELS_PER_CM = 178 / 10  # Ensure this is accurate

# Initialize video capture
cap = cv2.VideoCapture(2)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Perform object detection
    results = model.predict(frame, conf=0.5)  # Removed show=True for better OpenCV handling

    for result in results:
        boxes = result.boxes  # Extract bounding box results
        for box in boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])  # Get bounding box coordinates
            
            width_pixels = x2 - x1
            height_pixels = y2 - y1

            # Use midpoints for better measurement accuracy
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2
            
            # Convert pixels to cm
            width_cm = width_pixels / PIXELS_PER_CM
            height_cm = height_pixels / PIXELS_PER_CM

            # Get class and confidence
            conf = box.conf[0].item()  # Confidence score
            cls = int(box.cls[0].item())  # Class ID
            label = model.names[cls]  # Class name

            # Draw bounding box and measurement text
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            text = f"{label} W: {width_cm:.2f}cm, H: {height_cm:.2f}cm"
            cv2.putText(frame, text, (x1, y1 - 10), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (36, 255, 12), 2)

    # Display the frame
    cv2.imshow('YOLOv8 Object Measurement', frame)

    # Exit on ESC key
    if cv2.waitKey(1) & 0xFF == 27:
        break

cap.release()
cv2.destroyAllWindows()
