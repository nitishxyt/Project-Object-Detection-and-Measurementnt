import cv2
import torch
import numpy as np
from ultralytics import YOLO

# Load YOLOv8 model
model = YOLO("yolov8n.pt")

# Camera calibration
PIXELS_PER_CM = 188/10

# Initialize video capture
cap = cv2.VideoCapture(2)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Perform object detection
    results = model.predict(frame, conf=0.5, show=True)  # Set confidence threshold

    for result in results:
        boxes = result.boxes  # Extract bounding box results
        for box in boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])  # Get bounding box coordinates
            conf = box.conf[0].item()  # Get confidence score
            cls = int(box.cls[0].item())  # Get class ID
            label = model.names[cls]  # Get class label

            # Calculate dimensions in cm
            width_cm = (x2 - x1) / PIXELS_PER_CM
            height_cm = (y2 - y1) / PIXELS_PER_CM

            # Draw bounding box
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, f"{label} W: {width_cm:.2f}cm, H: {height_cm:.2f}cm", 
                        (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (36, 255, 12), 2)

    # Show the frame
    cv2.imshow('YOLOv8 Detection', frame)

    # Exit on ESC key
    if cv2.waitKey(1) & 0xFF == 27:
        break

cap.release()
cv2.destroyAllWindows()
