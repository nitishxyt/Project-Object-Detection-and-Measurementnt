import cv2
import math
import torch
from ultralytics import YOLO

# Variables for manual measurement
points = []
ratio_w = 10 / 178  # Adjust according to actual measurements
ratio_h = 15 / 271  # Adjust according to actual measurements

# Camera calibration for YOLO-based measurement
PIXELS_PER_CM = 188 / 10

# Load YOLOv8 model
model = YOLO("yolov8n.pt")

# Define mouse event for manual measurement
def draw_circle(event, x, y, flags, param):
    global points
    if event == cv2.EVENT_LBUTTONDOWN:
        if len(points) == 2:
            points = []
        points.append((x, y))

# Initialize video capture
cap = cv2.VideoCapture(2)
cv2.namedWindow("frame")
cv2.setMouseCallback("frame", draw_circle)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Manual measurement
    for pt in points:
        cv2.circle(frame, pt, 5, (0, 0, 255), -1)

    if len(points) == 2:
        pt1, pt2 = points
        dx = (pt2[0] - pt1[0]) * ratio_w  # Convert x-axis distance
        dy = (pt2[1] - pt1[1]) * ratio_h  # Convert y-axis distance
        distance_cm = math.sqrt(dx**2 + dy**2)  # Euclidean distance in cm
        cv2.putText(frame, f"Manual: {distance_cm:.2f} cm", (pt1[0], pt1[1] - 10), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, (36, 255, 12), 2)

    # YOLO object detection
    results = model.predict(frame, conf=0.5)  # Perform object detection with YOLO

    for result in results:
        boxes = result.boxes  # Extract bounding box results
        for box in boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])  # Get bounding box coordinates
            conf = box.conf[0].item()  # Get confidence score
            cls = int(box.cls[0].item())  # Get class ID
            label = model.names[cls]  # Get class label

            # Calculate dimensions in cm
            width_cm = (x2 - x1) / PIXELS_PER_CM
            height_cm = (y2 - y1) / PIXELS_PER_CM

            # Draw bounding box and dimensions on the frame
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, f"{label} W: {width_cm:.2f}cm, H: {height_cm:.2f}cm", 
                        (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (36, 255, 12), 2)

    # Display the frame
    cv2.imshow('frame', frame)

    # Exit on ESC key
    key = cv2.waitKey(1)
    if key == 27:  # ESC key
        break

# Release video capture and destroy windows
cap.release()
cv2.destroyAllWindows()
